package com.mike;

public interface Payable {
    double pay();
}
