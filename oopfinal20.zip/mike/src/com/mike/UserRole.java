package com.mike;

//TODO:write the code
public enum UserRole {
    ROLE_CASHIER,
    ROLE_MANAGER
}
