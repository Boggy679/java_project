package com.mike;

import java.util.ArrayList;
import java.util.List;


public class Store {
    public static final List<Basket> basketList = new ArrayList<>();
    
}
